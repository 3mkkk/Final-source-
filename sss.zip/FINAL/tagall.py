from telethon import events
import FINAL.client
import asyncio
import random

client = FINAL.client.client

active_tasks = {}

@client.on(events.NewMessage(outgoing=True, pattern=r"\.ايقاف التاك$"))
async def tagall(event):
    chat_id = event.chat_id
    task = active_tasks.get(chat_id)
    if task:
        task.cancel()
        del active_tasks[chat_id]
        await event.respond("تم إيقاف التاك.")
    else:
        await event.respond("لا يوجد تاك نشط حالياً.")

def is_valid_user(user, me, participants_set):
    return (
        user
        and not user.bot
        and not user.deleted
        and user.id != me.id
        and user.id not in participants_set
    )

@client.on(events.NewMessage(outgoing=True, pattern=r"\.(تاك_للكل|all)(.*)"))
async def tagall(event):
    try:
        message_text = event.pattern_match.group(2).strip()
        chat = await event.get_input_chat()
        me = await client.get_me()
        participants_set = set()

        started_msg = await event.respond("**بدء التاك...**")
        await asyncio.sleep(1)
        await started_msg.delete()

        async def tag():
            temp_mentions = []
            async for user in client.iter_participants(chat):
                if not is_valid_user(user, me, participants_set):
                    continue
                participants_set.add(user.id)
                name = user.first_name or "مستخدم"
                temp_mentions.append(f"[{name}](tg://user?id={user.id})")
                if len(temp_mentions) == 20:
                    msg = (f"**{message_text}**\n\n" if message_text else "") + "\n".join(temp_mentions)
                    await client.send_message(chat, msg, parse_mode="markdown")
                    temp_mentions = []
                    await asyncio.sleep(1)
            if temp_mentions:
                msg = (f"**{message_text}**\n\n" if message_text else "") + "\n".join(temp_mentions)
                await client.send_message(chat, msg, parse_mode="markdown")

        task = asyncio.create_task(tag())
        active_tasks[event.chat_id] = task
        await task
        del active_tasks[event.chat_id]

    except Exception as e:
        await event.respond("حدث خطأ أثناء تنفيذ الأمر.")

@client.on(events.NewMessage(outgoing=True, pattern=r"\.تاك_فردي\s+(\d+)\s+(.+)$"))
async def tagall(event):
    try:
        delay = int(event.pattern_match.group(1))
        message_text = event.pattern_match.group(2).strip()
        chat = await event.get_input_chat()
        me = await client.get_me()
        participants_set = set()

        started_msg = await event.respond("**بدء التاك الفردي...**")
        await asyncio.sleep(1)
        await started_msg.delete()

        async def tag():
            async for user in client.iter_participants(chat):
                if not is_valid_user(user, me, participants_set):
                    continue
                participants_set.add(user.id)
                name = user.first_name or "مستخدم"
                mention = f"[{name}](tg://user?id={user.id})"
                await client.send_message(chat, f"{message_text} {mention}", parse_mode="markdown")
                await asyncio.sleep(delay)

        task = asyncio.create_task(tag())
        active_tasks[event.chat_id] = task
        await task
        del active_tasks[event.chat_id]

    except:
        return

@client.on(events.NewMessage(outgoing=True, pattern=r"\.تاك\s+(\d+)$"))
async def tagall(event):
    try:
        delay = int(event.pattern_match.group(1))
        reply = await event.get_reply_message()
        if not reply or not reply.text:
            return await event.respond("❌ يجب الرد على رسالة تحتوي جمل (كل جملة في سطر)")

        lines = [line.strip() for line in reply.text.splitlines() if line.strip()]
        if not lines:
            return await event.respond("❌ لا توجد جمل صالحة في الرسالة.")

        chat = await event.get_input_chat()
        me = await client.get_me()
        participants_set = set()

        started_msg = await event.respond("**بدء التاك العشوائي...**")
        await asyncio.sleep(1)
        await started_msg.delete()

        async def tag():
            async for user in client.iter_participants(chat):
                if not is_valid_user(user, me, participants_set):
                    continue
                participants_set.add(user.id)
                line = random.choice(lines)
                name = user.first_name or "مستخدم"
                mention = f"[{name}](tg://user?id={user.id})"
                await client.send_message(chat, f"{line} {mention}", parse_mode="markdown")
                await asyncio.sleep(delay)

        task = asyncio.create_task(tag())
        active_tasks[event.chat_id] = task
        await task
        del active_tasks[event.chat_id]

    except:
        return

@client.on(events.NewMessage(outgoing=True, pattern=r"\.منشن$"))
async def tagall(event):
    help_text = """
**شرح أوامر المنشن:**

1. `.تاك_للكل` + *رسالة اختيارية*  
- منشن جماعي لكل الأعضاء برسالة واحدة تحتوي 20 شخص في كل رسالة.

2. `.تاك_فردي+ثواني+رسالة`  
- منشن فردي لكل عضو في رسالة مستقلة، مع تحديد وقت بين كل منشن.  
- مثال: `.تاك_فردي 5 تعال بسرعة`

3. `.تاك+ثواني`  
- يجب الرد على رسالة تحتوي عدة جمل (كل جملة في سطر).  
- يتم اختيار جملة عشوائية لكل شخص ومنشنه بها.  
- مثال للرسالة: 
```
مختفي 
مشتاقين 
وينك
```
ثم الرد عليها بامر: `.تاك 5`

4. `.ايقاف التاك`  
- لإيقاف أي عملية تاك نشطة.

**ملاحظات:**  
- يتم تجاهل البوتات والمشرفين ونفسك من المنشن.  
"""
    await event.respond(help_text, parse_mode="markdown")       